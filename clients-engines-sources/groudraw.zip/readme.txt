"GROUDRAW" demos by Ken Silverman (http://advsys.net/ken)

---------------------------- A T T E N T I O N !! ----------------------------

Run "RUNME1ST.BAT" to generate C1.DTA and D1.DTA. These data files must exist
for many of the demos.

-------------------------------- Introduction --------------------------------

This is a collection of heightmap voxel demos I wrote before Voxlap. As you
can see, I did a lot of research years before writing Voxlap - things didn't
all come together at once!

The reason I am finally releasing these demos is because I never had access to
copyright free data - until now. I asked my friend, Tom Dobrowolski
(http://ged.ax.pl/~tomkh/) to write a landscape generator for me because he
has a lot more experience with this kind of stuff. For the benefit of the
public, we are offering our DTA files (as well as GENLAND.*) free for public
distribution.

-Ken S.

--------------------------- File description, etc. ---------------------------

Common keys to all demos:
	ESC: quit
	Arrows/mouse: movement/turning
	Left Shift/Right Shift: move at double/half/4x/quarter speed
	Right Ctrl + arrows: move left/right (GROUDRAW/GROUCOM/GROUCUBE)
	Right Ctrl/Keypad 0: move up/down (GROU6D/STEEP/STEEP2)
	A/Z: move up/down (GROUDRAW/GROUCUBE/GROUCOM/OVERGROU)
	+/- or PGUP/PGDN: look up/down (GROUDRAW/GROUCUBE/GROUCOM)
	PGUP/PGDN: Raise/lower terrain under cursor (GROU6D/STEEP/STEEP2)

RUNME1ST.BAT (December 2005): A simple batch file that executes GENLAND.EXE
	with the /DTA option.

GENLAND.EXE (November 2005): The heightmap data generator required for most
	demos. Tom Dobrowolski wrote the original generator algorithm. I modified
	his code to output Comanche-compatible data format (as well as other
	formats.) For these demos, run GENLAND with the /DTA option (or simply use
	the provided batch file, RUNME1ST.BAT. The generated files are:
		C1.DTA (1,187,282 bytes)
		D1.DTA (  895,964 bytes)
	Note that these files are compatible with NovaLogic's Comanche Maximum
	Overkill data. (For the curious, the format is actually 8-bit PCX. The
	real Comanche data just has the header replaced with the creator's name.)

GENLAND.CPP: Source code to GENLAND.EXE - for those who are curious. This code
	is written for Microsoft Visual C/C++ 6.0.

GROUDRAW.EXE (April 1993): My 1st "Ground Drawing" heightmap voxel engine.
	This one was written in 16-bit Microsoft C (All others use 32-bit Watcom C)
	Command Line options:
		>groudraw 4    320*200, 4x1 pixels (default)
		>groudraw 2    320*200, 2x1 pixels
		>groudraw 1    320*200, 1x1 pixels
		>groudraw -4   360*240, 4x1 pixels
		>groudraw -2   360*240, 2x1 pixels
		>groudraw -1   360*240, 1x1 pixels (highest resolution)

GROUCOM.EXE (October 1993): My 1st heightmap voxel engine to load Comanche
	data. Additional in-game controls:
		1 = 1x1 pixels (default)
		2 = 2x1 pixels
		4 = 4x1 pixels

GROUCUBE.EXE (December 1993): My 1st heightmap voxel engine to sample at grid
	intersections. Additional in-game controls:
		Q = 1x1 pixels (default)
		W = 2x1 pixels
		E = 4x1 pixels
		S = 320*400 mode (default)
		D = 320*200 mode

OVERGROU.EXE (March 1997): My 1st heightmap voxel engine to use a view that
	doesn't look straight towards the horizon. OVERGROU uses a fullscreen
	lookup table for atan2 and sqrt to project color data to the screen in a
	2nd pass. I always thought this engine would work nicely for a Death Rally
	type game :)

GROU6D.EXE (June 1997): My 1st 6 degree of freedom heightmap voxel engine.
	This was my first project to take advantage of MMX - mainly for the extra
	register space, but also helpful for parallel multiplies. (I got my first
	MMX-capable machine, a Pentium II, just 1 month earlier).

STEEP.EXE (June 1997): My 1st heightmap voxel engine to support multiple
	color values per column. This gives much better resolution on steep slopes.
	Try comparing the difference in detail on high slopes between STEEP and
	GROU6D. Requires MMX.

STEEP2.EXE (December 2001): After I was well into writing the Voxlap engine, I
	wanted to see how well my latest tricks would work in an older heightmap
	engine. STEEP2 is basically STEEP with a sky and upgraded to 16-bit color.
	The 16-bit color allows the sky to have an independent palette from the
	landscape) Requires Pentium III or above.

GROUDRAW.DAT: Data for GROUDRAW.EXE. Brief description of file format:
	unsigned char pal[3][256], hgt[256][256], col[256][256];

TOONSKY.JPG: A sky image used by STEEP2.EXE, originally created by Tom
	Dobrowolski for the Voxlap demo.

TABLES.DAT: Math tables/fonts used by GROUDRAW.EXE and GROUCUBE.EXE.

GROUDRAW_SRC.ZIP: Source code to all heightmap demos. To compile GROUDRAW.C,
	you need to use an old version of 16-bit Microsoft C. If you don't have it,
	don't waste your time. To compile all other demos, use OpenWatcom 1.3
	(http://openwatcom.org/) and type "wmake all".

README.TXT: This file.

------------------------------------------------------------------------------
GROUDRAW source code license:

[1] Any derivative works based on one of the above demos may be distributed
	 freely through the internet. If you wish to use anything for a commercial
	 application, please consult with me first about acquiring a license.

[2] You must give me proper credit. This line of text is sufficient:

		 [insert demo name] by Ken Silverman (http://advsys.net/ken)

	 Make sure it is clearly visible somewhere in your archive.

[3] I encourage but not require you to release any modified source code that
	 could be useful. If you do so, please add the following line to each
	 source file changed:

	// This file has been modified from Ken Silverman's original release
------------------------------------------------------------------------------
Contact info:

 1. My personal forum: "advsys.net/ken" at http://jonof.edgenetwork.org

 2. E-mail (address can be found at the bottom of my main page). Please use
	 this for license requests.

-Ken S. (official website: http://advsys.net/ken)
------------------------------------------------------------------------------
