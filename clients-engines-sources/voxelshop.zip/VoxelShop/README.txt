MAC ADVICE
==========

For mac open console, navigate to PS4k folder and write
  chmod 764 start.command
(only if right level not sufficient)
NOTE: Make sure you have the latest java version!



LINUX ADVICE
============

You need to be using the oracle java version. You can 
install it as follows:
  sudo add-apt-repository ppa:webupd8team/java
  sudo apt-get update
  sudo apt-get install oracle-java7-installer
Similar to MAC you will need to change the permission 
of the start.cmd file before you can execute it.



Samples
=======

The sample files might be copyrighted.



License
=======

This software (alpha) is released as freeware. I'm asking that, instead
of distributing it, you direct people who are interested in it to
http://www.blackflux.com



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, please post on the forum at http://www.blackflux.com/forums/




Copyright 2012 - 2014 BlackFlux.com
http://www.blackflux.com