#!/bin/bash
cd "$(dirname "$0")"
java -jar data/getdown-client.jar data
